
exports.save_data = (country) => `
INSERT INTO ${
  process.env[`${country}_DELIVER_SCHEMA`]
}.deliver_order_status ( country_code, distribution_id,  tour_id, delivery_document, document_transport,
      status_transport, order_num, order_status, skus ,delivered_quantity ,planned_quantity, sku_status ,reason_rejection, customer_id, 
      visit_date_ini, visit_date_end, delivery_date, dtlastmodifieddate) 
     `;

  exports.delete_data = (country, date) =>
  ` DELETE FROM ${
    process.env[`${country}_DELIVER_SCHEMA`]
  }.deliver_order_status WHERE dtlastmodifieddate < '${date}' ::timestamp`;
  
  exports.vacuum_full = (country) => 
  `VACUUM FULL ${
    process.env[`${country}_DELIVER_SCHEMA`]
  }.deliver_order_status `
  
  exports.reindex_table = (country) =>
  `REINDEX TABLE ${
    process.env[`${country}_DELIVER_SCHEMA`]
  }.deliver_order_status`;
  

  