const parse = require("pg-connection-string").parse;

const createDBInstance = (connString) => {
    const pgconfig = parse(connString);
    pgconfig.ssl = { rejectUnauthorized: false };
    
    return require("knex")({
        client: "pg", 
        connection: pgconfig
    });
}

const executeOnceAsync = async (knex, query, params) => {
    //console.log(`Query >>> ${query}`);
    return await knex.raw(query, params)
        .then(values => {
            console.log("Process rows: " + values.rowCount);
            return values
        })
        .catch(error => {
            knex.destroy();
            throw new Error(error);
        })
}

module.exports = {
    createDBInstance,
    executeOnceAsync
}