const Constants = require("./constants");
const axios = require('axios');
const uuid = require('uuid/v4');
const { createDBInstance, executeOnceAsync } = require("./dbInstance");
const { rangeDates } = require('./utils');
const { save_data, delete_data, vacuum_full, reindex_table } = require('./queries');

const poolByCountry = {
  PE: process.env['PE_DELIVER_DB'],
  PA: process.env['PA_DELIVER_DB'],
  EC: process.env['EC_DELIVER_DB'],
};


async function fetchData(uuid, queryParams, accessToken, country, context) {
    context.log(`CompletedTours data for country ${country} with requestTraceId ${uuid} Range date : ${queryParams.startTimestamp}`);
    const apiUrl = process.env[`BEES_COMPLETED_TOURS_URL`];
    const customHeaders = {
        Authorization: `Bearer ${accessToken}`,
        requestTraceId: uuid,
        country: country
    };
    try {
        const response = await axios.get(apiUrl, {
            params: queryParams,
            headers: customHeaders
        });
        context.log(`Data fetched successfully for country ${country}`);
        const processedData = extractStatusAndType(response.data);
        return processedData;
    } catch (error) {
        context.log(`Error fetching data for country ${country}: ${error.message}`);
        throw new Error(`Error message ${error}`);
    }
}

async function patchData(reqtraceid, data, accessToken, country, context) {
    context.log(`Patching data for country ${country} with requestTraceId ${reqtraceid}`);
    const apiUrl = `https://${
        process.env['BEES_HOST_URL']
    }/${
        process.env['BEES_DATAINGESTION_URL']
    }`;
    const customHeaders = {
        Authorization: `Bearer ${accessToken}`,
        requestTraceId: reqtraceid,
        country: country
    };

    const payload = {
        entity: "ORDERS",
        version: "v3",
        payload: data
    };
    try {
        const response = await axios.patch(apiUrl, payload, {headers: customHeaders});
        context.log(`Data patched successfully for country ${country}`);
        return response ? true : false;
    } catch (error) {
        context.log(`Error patching data for country ${country}: ${error.message}`);
        throw new Error("Error al realizar la solicitud PATCH", error.message);
    }
}

async function validateOrderStatus(accessToken, reqtraceid, status, orderId, country) {
    let orderUpdate;
    const apiUrl = process.env['BEES_ORDER_STATUS_URL'];
    const customHeaders = {
        Authorization: `Bearer ${accessToken}`,
        requestTraceId: reqtraceid,
        country: country,
        accept: "application/json"
    };
    const requestParams = new URLSearchParams({orderStatus: status, orderIds: orderId});
    try {
        const {
            data = {}
        } = await axios.get(apiUrl, {
            params: requestParams,
            headers: customHeaders
        });

        const {
            orders = []
        } = data;
        const [order = {}
        ] = orders;
        const {
            orderNumber = '',
            previousStatus = '',
            status = '',
            audit = {}
        } = order;
        const {
            updateAt = ''
        } = audit;

        orderUpdate = {
            orderNumber: orderNumber,
            statusPrevio: previousStatus,
            statusActualizado: status,
            fechaActualización: updateAt
        };
        return orderUpdate;
    } catch (error) {
        throw new Error("Error al realizar la solicitud ValidateOrder", error.message);
    }
}

async function ordersToValidate(processedData, token, traceid, country) {
    ordersUpdate = [];
    for (const orderObj of processedData) {
        const order = orderObj.order;
        const orderId = order.orderNumber;
        const status = order.status;
        try {
            const validateUpdateStatus = await validateOrderStatus(token, traceid, status, orderId, country);
            ordersUpdate.push(validateUpdateStatus);
        } catch (error) {
            throw new Error(`Error validating order ${orderId}: ${
                error.message
            }`);
        }
    }
    return ordersUpdate;
}

function extractStatusAndType(data = {}) {
    //console.log(`data extract ${JSON.stringify(data)}`);
    const ordersToUpdate = [];
    const registryBD = [];
    const content = data.content;
    const totalElements = data.pagination.totalElements;
    let orderNumbersSet = new Set();
    for (let i = 0; i < totalElements; i++) {
        for (const trip of content[i].trips) {
            trip.visits.forEach((visit) => {
                let deliveryDocs = visit.documents;
                let filterValid = deliveryDocs.filter((doc) => Constants.typeValid.includes(doc.type) && doc.orderId != null);
                let filterValidOrder = deliveryDocs.filter((doc) => Constants.typeValidOrder.includes(doc.type) && doc.orderId != null);
                let uniqueDocs = filterValidOrder.filter((doc) => {
                    if (! orderNumbersSet.has(doc.orderId)) {
                        orderNumbersSet.add(doc.orderId, doc.type);
                        return true;
                    }
                    return false;
                });
                registryBD.push(
                  ...filterValid.map((doc) => ({
                    registry: {
                      distibutionCenter: content[i].distributionCenterExternalId,
                      statusTransport: content[i].status, //status del transporte
                      displayId: content[i].displayId, //Documento transporte
                      dateEntrega: content[i].date, //fecha de entrega
                      dateInit: visit.arrivedAt, //inicio visita
                      dateEnd: visit.finishedAt, //fin visita
                      accountId: visit.accountId, //cliente
                      order: {
                        externalId: doc.externalId, //Documento de entrega
                        documentType: doc.type,
                        status: Constants.statusMapping[doc.status] || "DENIED",
                        orderNumber: doc.orderId,
                        skus: doc.executedItems.map((item) => ({
                          sku: item.sku,
                          quantity: item.quantity,
                          originalquantity: item.originalQuantity,
                          status: (item.quantity === 0) ? 'NON_DELIVERED' : item.status,
                        })),
                    }
                    },
                  }))
                );
                ordersToUpdate.push(... uniqueDocs.map((doc) => ({
                    order: {
                        status: Constants.statusMapping[doc.status] || "DENIED",
                        orderNumber: doc.orderId
                    }
                })));
            });
        }
    }
    return {ordersToUpdate, registryBD};
}

async function cleanDB(pool, country, context) {
    context.log(`Cleaning DB for country ${country}`);
  const date = new Date();
  const daysToSubtract = Constants.dayscleanDB || 15;
  date.setDate(date.getDate() - daysToSubtract); 
  const formattedDate = new Date(date).toISOString();
  await executeOnceAsync(pool,delete_data(country, formattedDate));
  await executeOnceAsync(pool,vacuum_full(country) );
  await executeOnceAsync(pool,reindex_table(country));
  context.log(`DB cleaned for country ${country}`);
}


async function insertarRegistrosBD(data = [], country = '', context) {
    context.log(`Inserting records into DB for country ${country} rows ${data.length}`);
  const pool = poolByCountry[country];
  const knex = createDBInstance(pool)
  try {
    const currentDate = new Date();
    const timestamp = new Date(currentDate).toISOString();
    const batchSize = process.env.LOTE_UPDATEDB_DELIVER_STATUS || 200;
    const batches = [];
    for (let i = 0; i < data.length; i += batchSize) {
      batches.push(data.slice(i, i + batchSize));
    }
    for (const batch of batches) {
        context.log(`Processing batch ${batch}`);
        const values = [];
        const placeholders = [];

        batch.forEach(objeto => {
            const registro = objeto.registry;
            registro.order.skus.forEach(skuData => {
                const dateInit = registro.dateInit !== undefined ? registro.dateInit : timestamp;
                const dateEnd = registro.dateEnd !== undefined ? registro.dateEnd : timestamp;

                values.push(
                    country,
                    registro.distibutionCenter,
                    registro.displayId,
                    registro.displayId,
                    registro.order.externalId,
                    registro.statusTransport,
                    registro.order.orderNumber,
                    registro.order.status,
                    skuData.sku,
                    skuData.quantity,
                    skuData.originalquantity,
                    skuData.status,
                    '',
                    registro.accountId,
                    dateInit,
                    dateEnd,
                    registro.dateEntrega,
                    timestamp
                );

                placeholders.push('(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)');
            });
        });

        const queryWithValues = `${save_data(country)} VALUES ${placeholders.join(', ')}`;
        context.log(`Extract values >>> ${values}`);
        const result = await executeOnceAsync(knex, queryWithValues, values);
        context.log(`Processed rows in DB: ${result.rowCount} for country ${country}`);
    }
    await cleanDB(knex,country, context);
  } catch (error) {
    console.error("Error al insertar los registros:", error);
    throw error;
  } 
}


module.exports = async function (context) {
    context.log(`Initial Job process to country ${Constants.country}`);
    const rangeDate = rangeDates(Constants.numExecution );
    context.log(`Range to Process ${rangeDate.initDateISO} - ${rangeDate.endDateISO}`);
    if(Constants.develop){
        rangeDate.initDateISO = Constants.dateIni
        rangeDate.endDateISO = Constants.dateEnd
        context.log(`New Range Develop to Process ${rangeDate.initDateISO} - ${rangeDate.endDateISO}`);
    };
    const queryParams = {
        startTimestamp: rangeDate.initDateISO,
        endTimestamp: rangeDate.endDateISO,
        country: Constants.country
    };
    const enableValidateUpdateStatus = process.env[`${
            queryParams.country
        }_ENABLE_VALIDATE_UPDATE_STATUS`] === 'true';

    const clientCredentials = {
        id: process.env[`${
                queryParams.country
            }_BEES_CLIENT_ID`],
        secret: process.env[`${
                queryParams.country
            }_BEES_CLIENT_SECRET`]
    };
    const reqtraceid = uuid();
    try {
        let bodyMessage = '';
        const accessTokenTours = await getAccessToken(process.env[`${
                queryParams.country
            }_DELIVER_TOKEN_CLIENTID`], process.env[`${
                queryParams.country
            }_DELIVER_TOKEN_CLIENTSECRET`], process.env[`${
                queryParams.country
            }_DELIVER_VENDOR_ID`], reqtraceid);
        const {
            ordersToUpdate = '',
            registryBD = ''
        } = await fetchData(reqtraceid, queryParams, accessTokenTours, queryParams.country, context);
        let allBatchesProcessedSuccessfully = true; 
        if (ordersToUpdate.length > 0) {
            const maxBatchSize = process.env[`${
                    queryParams.country
                }_LOTE_UPDATE_DELIVER_STATUS`] || 500;
            const numBatches = Math.ceil(ordersToUpdate.length / maxBatchSize);
            const accessTokenOrder = await getAccessToken(clientCredentials.id, clientCredentials.secret, '', reqtraceid);
            for (let i = 0; i < numBatches; i++) {
                const start = i * maxBatchSize;
                const end = (i + 1) * maxBatchSize;
                const batchData = ordersToUpdate.slice(start, end);
                const jsonString = JSON.stringify(batchData).replace(/"/g, '"');
                const patchResult = true
                await patchData(reqtraceid, jsonString, accessTokenOrder, queryParams.country,context);
                allBatchesProcessedSuccessfully = !patchResult ? false : true;
                let validateUpdateStatus = "No se invoca validateUpdateStatus";
                if (enableValidateUpdateStatus && patchResult) {
                    validateUpdateStatus = await ordersToValidate(batchData, accessTokenOrder, reqtraceid, queryParams.country);
                }              

                bodyMessage += ` Batch ${
                    i + 1
                }/${numBatches} - TraceId : ${reqtraceid} \n ${
                    JSON.stringify(validateUpdateStatus)
                }\n`;
            }
            if (! enableValidateUpdateStatus) {
                bodyMessage += `Processed Deliver Data: ${
                    JSON.stringify(ordersToUpdate)
                }\n`;
            }

        } else {
            bodyMessage = JSON.parse('{"message":"No se encontraron ordenes para actualizar"}');
        } 

        if (registryBD.length > 0) {
            allBatchesProcessedSuccessfully = true ? await insertarRegistrosBD(registryBD, queryParams.country, context) : "No se actualiza data";
        } else {
            context.log("No hay elementos para insertar en la base de datos");
        }

    } catch (error) {
        context.log("Error al realizar la consulta CompletedTours:", error.message);
    }
};

async function getAccessToken(clientId, clientSecret, vendorId, reqtraceid) {
    let accessToken;
    const apiUrl = process.env['BEES_AUTHENTICATION_URL'];

    const requestHeader = {
        "content-type": "application/x-www-form-urlencoded",
        requestTraceId: reqtraceid
    };

    const requestParams = new URLSearchParams({grant_type: "client_credentials", client_id: clientId, client_secret: clientSecret, scope: process.env['SCOPE']});

    if (vendorId !== '') {
        requestParams.append('vendor_id', vendorId);
    }

    try {
        const response = await axios.post(apiUrl, requestParams.toString(), {headers: requestHeader});
        accessToken = response.data;
        return accessToken.access_token;
    } catch (error) {
        throw new Error(`Error message: ${
            error.response ? JSON.stringify(error.response.data) : JSON.stringify(error.message)
        }`);
    }
}
