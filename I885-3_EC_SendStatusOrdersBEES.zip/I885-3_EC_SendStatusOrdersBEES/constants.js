module.exports = {
  develop: false,
  date: '2024-05-01',
  numExecution: 4,
  country: 'EC',
  timezone: 'America/Mexico_City',
  dayscleanDB: 15,
  statusMapping : {
      CONCLUDED: "DELIVERED",
      PARTIAL_DELIVERY: "PARTIAL_DELIVERY",
      WAITING: "DENIED",
      MODULATION: "DENIED",
      PENDING: "DENIED"
  },
  typeValid : ["PRODUCT_DELIVERY", "REWARD"], 
  typeValidOrder : ["PRODUCT_DELIVERY"],
}
