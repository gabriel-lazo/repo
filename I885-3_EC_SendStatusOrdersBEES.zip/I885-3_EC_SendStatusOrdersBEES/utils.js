const moment = require('moment-timezone');
const Constants = require("./constants");

exports.convertToUTC = (dateString) => {
    const localTime = moment.tz(dateString, Constants.timezone);
    const utcDate = localTime.utc().toDate();
    console.log(`localtime convert ${utcDate},`);
    return utcDate;
}

exports.rangeDates = (numberSections = 1) => {
    const dateInMexico = moment.tz(Constants.timezone)
    const horaEjecucion = dateInMexico.hours() + dateInMexico.minutes() / 60;
    const sectionDuration = 24 / numberSections;
    let sectionIndex = Math.floor(horaEjecucion / sectionDuration);
    sectionIndex = Math.min(sectionIndex, numberSections - 1);
    const initHour = sectionIndex * sectionDuration;
    const endHour = (sectionIndex + 1) * sectionDuration;
    
    const initDateInMexico = dateInMexico.clone().hours(initHour).minutes(0).seconds(0);
    const endDateInMexico = dateInMexico.clone().hours(endHour).minutes(0).seconds(0);
    
    const initDateUTC = initDateInMexico.clone().utc();
    const endDateUTC = endDateInMexico.clone().utc();
    
    console.log(`$$$$$$$$initDateISO ${initDateUTC.toISOString()} endDateISO: ${endDateUTC.toISOString()}`);
    
    return { initDateISO: initDateUTC.toISOString(), endDateISO: endDateUTC.toISOString() };
}

